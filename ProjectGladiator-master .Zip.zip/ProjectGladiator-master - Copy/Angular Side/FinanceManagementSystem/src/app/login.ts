import {Customer} from './customer'
 
export class Login {
    username: string;
    password: string;
    customer: Customer;
}
