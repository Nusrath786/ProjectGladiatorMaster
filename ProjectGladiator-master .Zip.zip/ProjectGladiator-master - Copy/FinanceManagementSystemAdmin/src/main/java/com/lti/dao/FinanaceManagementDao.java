package com.lti.dao;

import java.util.List;

import com.lti.model.Customer;
import com.lti.model.Login;

public interface FinanaceManagementDao {
	public int createCustomer(Login login);
	public Login viewUser(String username);
	int displayCustomerdetails(Customer customer);
	public Customer displayUser(String username);
	public int displayCustomer(Customer customer);
		
}
