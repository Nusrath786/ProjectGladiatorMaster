package com.lti.service;

import java.util.List;

import com.lti.model.Customer;
import com.lti.model.Login;

public interface FinanaceManagementService {
	
	public boolean addCustomer(Login login);
	public Login findUser(String username);
	public boolean fetchCustomerdetails(Customer customer);
	public Customer displayUser(String username);
	

}
